<?php
    require 'connection.php';
    session_start();
    if(!isset($_SESSION['email'])){
        header('location: login.php');
    }
    $user_id=$_SESSION['id'];
    $user_products_query="SELECT * FROM `orders` WHERE user_id='$user_id' AND status='Added to cart' order by order_id ASC ";
    $user_products_result=mysqli_query($con,$user_products_query) or die(mysqli_error($con));
    $no_of_user_products= mysqli_num_rows($user_products_result);
    $sum=0;
    if($no_of_user_products==0){
        //echo "Add items to cart first.";
    ?>
        <script>
        window.alert("No items in the cart!!");
        </script>
    <?php
    }else{
        while($row=mysqli_fetch_array($user_products_result)){
            $sum=$sum+$row['total_price']; 
       }
    }
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>Mobile Space | Cart</title>
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>

    </head>
    <body>
        <div>
            <?php 
               require 'header.php';
            ?>
            <br><br>
            <div class="container">
  <h4>5-Steps to Place an Order---</h4>
  <div class="progress">
  <div class="progress-bar bg-primary" style="width:20%">1- login/sign up </div>
  <div class="progress-bar bg-danger" style="width:20%">2- Add to Cart</div>
  <div class="progress-bar bg-dark" style="width:20%">3- Confirm Cart</div>
</div>
<h3>Your Cart items</h3><br>
</div>
            <div class="container">
                <table class="table table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">No.#</th><th>Product title</th><th>Price</th><th>Qty</th><th>Total Price</th><th></th>
                        </tr>
                        </thead>
                       <?php 
                        $user_products_result=mysqli_query($con,$user_products_query) or die(mysqli_error($con));
                        $no_of_user_products= mysqli_num_rows($user_products_result);
                        $counter=1;
                       while($row=mysqli_fetch_array($user_products_result)){
                           
                         ?>
                        <tbody>
                        <tr>
                            <th><?php echo $counter ?></th><th><?php echo $row['item_name']?></th><th><?php echo $row['item_price']?></th>
                            <th><form method="post" action="update_quantity.php?id=<?php echo $row['order_id'] ?>">
                            <div class="form-group"><input type="number"  name="quantity" value="<?php echo $row['quantity']?>" min="0" max="20">
                            <input type="submit" class="" value="Update"></div></form></th>
                            <th><?php echo $row['total_price']?></th>
                            <th><a href="cart_remove.php?id=<?php echo $row['order_id'] ?>"><i class="fa fa-trash" aria-hidden="true"></i> Remove</a></th>
                        </tr>
                       <?php $counter=$counter+1;}?>
                    </tbody>
                </table>
                <div align="center">
              	<span style="font-size: 20px;"><b>Grand Total: Rs </b><?php echo $sum; ?> /-</span>
                </div>
                <div align="right">
                <a href="products.php" class="btn btn-primary">Add More items</a>
                <a href="checkout.php?id=<?php echo $user_id?>" class="btn btn-success">Confirm Cart</a>
            </div>
            </div>
        </div>
             <!--========== SCROLL REVEAL ==========-->
        <script src="https://unpkg.com/scrollreveal"></script>

        <!--========== MAIN JS ==========-->
        <script src="assets/js/main.js"></script>
    </body>
</html>
