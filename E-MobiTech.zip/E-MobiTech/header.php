<?php 
 include 'connection.php';
 session_start();
 ?>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <!--========== BOX ICONS ==========-->
        <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>

        <!--========== CSS ==========-->
        <link rel="stylesheet" href="assets/css/styles.css">
         <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.8.2/css/all.css">

<!-- Bootstrap CDN -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
               <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="assets/css/styles.css">
 
        <!--========== SCROLL TOP ==========-->
        <a href="#" class="scrolltop" id="scroll-top">
            <i class='bx bx-up-arrow-alt scrolltop__icon'></i>
        </a>
        
        <!--========== HEADER ==========-->
        <header class="l-header" id="header">
            <nav class="nav bd-container">
               <a href="index.php#home"><img  src="assets/img/logo3.png" width="70" height="50"style=" vertical-align:middle "></a>
                <div class="nav__menu" id="nav-menu">
                    <ul class="nav__list">
                        <li class="nav__item"><a href="index.php#home" class="nav__link"><h5>Home<h5></h5></a></li>
                        <li class="nav__item"><a href="index.php#brands" class="nav__link"><h5>Brands</h5></li>
                        <li class="nav__item"><a href="products.php?p=mobiles" class="nav__link"><h5>Mobiles</h5></li>
                        <li class="nav__item"><a href="products.php?p=accessories" class="nav__link"><h5>Accessories</h5></a></li>
                        <li><i class='bx bx-toggle-left change-theme' id="theme-button"></i></li>
                        <?php
                           if(isset($_SESSION['email'])){
                            $user_id=$_SESSION['id'];
                           ?>
                           <li class="nav__item"><a href="cart.php" class="nav__link" >
                            <?php 
                                //Sql Query 
                                $sql = "SELECT * FROM orders where status='Added to cart' and user_id=$user_id ";
                                //Execute Query
                                $res = mysqli_query($con, $sql);
                                //Count Rows
                                $count = mysqli_num_rows($res);
                            ?>

                                <h5 class="px-5 cart">
                                <i class="fas fa-shopping-cart"></i>  Cart  
                                <span id="cart_count" class="text-warning bg-dark"> <?php echo $count ?> </span></h5></a></li>
                                <?php 
                                //sql2 Query to display currently loged in user
                                $sql2 = "SELECT `name` FROM `users` WHERE id=$user_id ";
                                //Execute Query
                                $res2 = mysqli_query($con, $sql2);
                                //Fetch Row
                                $row = mysqli_fetch_array($res2);
                                $username=$row['name'];
                                ?>
                                <li class="nav__item">
                                <div class="dropdown">
                                      <a class="dropbtn" class="nav__link"><h5> <span class="glyphicon glyphicon-user"></span> <?php echo $username;?> <i class="fa fa-caret-down"></i></h5></a>
                                    <div class="dropdown-content">
                                            <a href="update-account.php?id=<?php echo $user_id;?>"><span><i class="fas fa-edit"></i></span> Update Account</a>
                                            <a href="user-order-history.php?id=<?php echo $user_id;?>"><span><i class="fa fa-history" aria-hidden="true"></i></span> View Order History</a>
                                            <a href="settings.php"><span class="glyphicon glyphicon-cog"></span> Password Settings</a>
                                            <a href="logout.php"><span class="glyphicon glyphicon-log-out"></span> Log Out</a>
                                    </div>
                                </div>    
                                </li>
                           <?php
                           }else{
                            ?>
                            <li class="nav__item"><a href="signup.php" class="nav__link"><h5 class="nav__link"><span class="glyphicon glyphicon-user"></span> Sign Up</h5></a></li>
                            <li class="nav__item"><a href="login.php" class="nav__link"><h5><span class="glyphicon glyphicon-log-in"></span> Login</h5></a></li>
                            <li class="nav__item"><a href="admin/index.php"class="nav__link"><h5><span class="glyphicon glyphicon-log-in"></span>Admin Panel</h5></a></li>
                           <?php
                           }
                           ?>
                       <!--  -->
                    </ul>
                </div>
                <div class="nav__toggle" id="nav-toggle">
                    <i class='bx bx-grid-alt'></i>
                </div>
            </nav>
        </header>
        <!--========== SCROLL REVEAL ==========-->
        <script src="https://unpkg.com/scrollreveal"></script>
