<?php 
require('connection.php');
 //1. Get the ID of Selected User
 $id=$_GET['id'];
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Mobile Space | Update/User Account</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/admin.css">

    </head>
<body>

<div class="main-content">
<div class="container">
        <a href="index.php" class="btn-primary">Back to Homepage</a>
    </div>
    <div class="wrapper">
        <h1>User Order History</h1>
        <br>
<p>----Recent Orders are at top in the list---</p>
                <table class="tbl-full">
                    <tr>
                        <th width="5%">No.#</th>
                        <th width="8%">Ordered-Date</th>
                        <th width="10%">Product title</th>
                        <th width="8%">Price</th>
                        <th width="5%">Qty</th>
                        <th width="8%">Total</th>
                        <th width="8%">Status</th>
                        <th width="10%">Customer</th>
                        <th width="10%">Contact</th>
                        <th width="18%"> Delivery Address</th>
                       
                    </tr>

                    <?php 
                        //Get all the orders and customer info. from database
                        $sql = "SELECT od.order_date,od.item_name,od.item_price,od.total_price,od.quantity,od.status,us.name,us.contact,us.address,us.city FROM orders od inner join users us on od.user_id=us.id WHERE od.user_id='$id' and (od.status!='Added to cart' && od.status!='waiting') order BY od.order_id DESC"; // DIsplay the Latest Order at First
                        //Execute Query
                        $res = mysqli_query($con, $sql);
                        //Count the Rows
                        $count = mysqli_num_rows($res);

                        $sn = 1; //Create a Serial Number and set its initail value as 1

                        if($count>0)
                        {
                            //Order Available
                            while($row=mysqli_fetch_array($res))
                            {
                                //Get all the order details
                                $item = $row['item_name'];
                                $price = $row['item_price'];
                                $qty = $row['quantity'];
                                $total = $row['total_price'];
                                $order_date = $row['order_date'];
                                $status = $row['status'];
                                $customer_name = $row['name'];
                                $customer_contact = $row['contact'];
                                $customer_address = $row['address'].'/ '.$row['city'];
                                
                                ?>

                                    <tr>
                                        <td><?php echo $sn++; ?> </td>
                                        <td><?php echo $order_date; ?></td>
                                        <td><?php echo $item; ?></td>
                                        <td>&#8360; <?php echo $price; ?></td>
                                        <td><?php echo $qty; ?></td>
                                        <td>&#8360; <?php echo $total; ?></td>

                                        <td>
                                            <?php 
                                                // Ordered, On Delivery, Delivered, Cancelled,Waiting,Added to cart item

                                                if($status=="Pending")
                                                {
                                                    echo "<label style='color: blue;'>$status</label>";
                                                }
                                                elseif($status=="On Delivery")
                                                {
                                                    echo "<label style='color: orange;'>$status</label>";
                                                }
                                                elseif($status=="Delivered")
                                                {
                                                    echo "<label style='color: green;'><b>$status</b></label>";
                                                }
                                                elseif($status=="Cancelled")
                                                {
                                                    echo "<label style='color: red;'>$status</label>";
                                                }
                                        
                                            ?>
                                        </td>

                                        <td><?php echo $customer_name; ?></td>
                                        <td><?php echo $customer_contact; ?></td>
                                        <td><?php echo $customer_address; ?></td>
                                    </tr>

                                <?php

                            }
                        }
                        else
                        {
                            //Order not Available
                            echo "<tr><td colspan='12' class='error'>Orders not Available</td></tr>";
                        }
                    ?>

 
                </table>
    </div>
    
</div>