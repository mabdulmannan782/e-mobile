<?php
    require 'connection.php';
    session_start();
    $order_id=$_GET['id'];
    $user_id=$_SESSION['id'];
    $delete_query="delete from orders where order_id='$order_id'";
    $delete_query_result=mysqli_query($con,$delete_query) or die(mysqli_error($con));
    header('location: cart.php');
?>