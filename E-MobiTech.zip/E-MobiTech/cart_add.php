<?php
    require 'connection.php';
    //require 'header.php';
    session_start();
    $item_id=$_GET['id'];
    $user_id=$_SESSION['id'];
    $q=1;
    $query="SELECT `new_price`,`title` FROM `items` where id='$item_id'  ";
    $queryfire=mysqli_query($con,$query);
    $product =mysqli_fetch_array($queryfire);
    $price=$product['new_price'];
    $item_name=$product['title'];
    $total_price=$price*$q;
    $add_to_cart_query="insert into orders(user_id,item_id,item_name,item_price,quantity,total_price,status) values ('$user_id','$item_id','$item_name','$price','$q','$total_price','Added to cart')";
    $add_to_cart_result=mysqli_query($con,$add_to_cart_query) or die(mysqli_error($con));
    header('location: cart.php');
?>