<?php 
  session_start();
	require 'connection.php';
  if(!isset($_SESSION['email'])){
    header('location:index.php');
}else{
    $user_id=$_SESSION['id'];
    date_default_timezone_set("Asia/karachi");//Timezone Pakistan
    date_default_timezone_get();
    $order_date = date('Y-m-d h:i:s a'); //Order Date
    $confirm_query="update orders set status='Pending', order_date='$order_date' where user_id=$user_id and status='Added to cart' " ;
    $confirm_query_result=mysqli_query($con,$confirm_query) or die(mysqli_error($con));
}
?>
<!DOCTYPE html>
<html>
    <head>
        <link rel="shortcut icon" href="img/lifestyleStore.png" />
        <title>Mobile-Space | Order Success</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!-- latest compiled and minified CSS -->
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <!-- jquery library -->
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <!-- Latest compiled and minified javascript -->
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <!-- External CSS -->
        <link rel="stylesheet" href="assets/css/styles.css" type="text/css">
    </head>
    <body>
            <?php
              require 'header.php';
            ?>
            <br><br><br>
            <div class="container">
  <h4>5-Steps to Place an Order---</h4>
  <div class="progress">
  <div class="progress-bar bg-primary" style="width:20%">1- login/sign up </div>
  <div class="progress-bar bg-danger" style="width:20%">2- Add to Cart</div>
  <div class="progress-bar bg-dark" style="width:20%">3- Confirm Cart</div>
  <div class="progress-bar bg-info" style="width:30%">4- Checkout</div>
  <div class="progress-bar bg-success" style="width:10%">5- Order Placed</div>
  </div>
            <br><br><br>
            <div class="container">
                <div class="row">
                    <div class="col-xs-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">THANK YOU</div>
                            <div class="panel-body">
                                <h4>Your order is Placed. Thank you for shopping with us. </h4>
                                <h4>View your Order History in user profile button at Header. OR<br><a href="user-order-history.php?id=<?php echo $user_id; ?>"> Click here!!</a></h4>
                                  <h5>For Delivery Details--Kindly Read out the Shipping mode Policy link in Footer. <br><br>
                            </div>
                        </div>
                    </div>
                    </div>
                    <br><br><br><br><br><br><br><br>
                    <br><br>
                <?php include("footer.php") ; ?>
    </body>
</html>
