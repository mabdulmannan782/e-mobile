
<?php require('partials/menu.php'); ?>

        <!-- Main Content Section Starts -->
        <div class="main-content">
            <div class="wrapper">
                <h1>Administrator Dashboard</h1>
                <br><br>
                <?php 
                    if(isset($_SESSION['login']))
                    {
                        echo $_SESSION['login'];
                        unset($_SESSION['login']);
                    }
                ?>
                <br><br>
                        <div class="col-4 text-center">

                    <?php 
                        //Sql Query 
                        $sql1= "SELECT `brand_name` FROM `items` group by brand_name having count(*) >=1 ";
                        //Execute Query
                        $res1 = mysqli_query($conn, $sql1);
                        //Count Rows
                        $count1 = mysqli_num_rows($res1);
                    ?>

                    <h1><?php echo $count1; ?></h1>
                    <br />
                    Brands
                </div>
                        <div class="col-4 text-center">

                    <?php 
                        //Sql Query 
                        $sql2= "SELECT * FROM items where type='mobile' ";
                        //Execute Query
                        $res2 = mysqli_query($conn, $sql2);
                        //Count Rows
                        $count2 = mysqli_num_rows($res2);
                    ?>

                    <h1><?php echo $count2; ?></h1>
                    <br />
                    Mobiles
                </div>



                <div class="col-4 text-center">

                    <?php 
                        //Sql Query 
                        $sql3 = "SELECT * FROM items where type='accessory' ";
                        //Execute Query
                        $res3 = mysqli_query($conn, $sql3);
                        //Count Rows
                        $count3 = mysqli_num_rows($res3);
                    ?>

                    <h1><?php echo $count3; ?></h1>
                    <br />
                    Accessories
                </div>


                <div class="col-4 text-center">
                    
                    <?php 
                        //Sql Query 
                        $sql4 = "SELECT * FROM tbl_admin";
                        //Execute Query
                        $res4 = mysqli_query($conn, $sql4);
                        //Count Rows
                        $count4 = mysqli_num_rows($res4);
                    ?>

                    <h1><?php echo $count4; ?></h1>
                    <br />
                    System Administrator
                </div>
                <div class="col-4 text-center">
                    
                    <?php 
                        //Sql Query 
                        $sql5 = "SELECT * FROM orders where (status!='Added to cart' ) ";
                        //Execute Query
                        $res5 = mysqli_query($conn, $sql5);
                        //Count Rows
                        $count5 = mysqli_num_rows($res5);
                    ?>

                    <h1><?php echo $count5; ?></h1>
                    <br />
                    Total Orders
                </div>

               

                <div class="col-4 text-center">
                    
                    <?php 
                        //Sql Query 
                        $sql6 = "SELECT * FROM orders WHERE status = 'Pending' ";
                        //Execute Query
                        $res6 = mysqli_query($conn, $sql6);
                        //Count Rows
                        $count6 = mysqli_num_rows($res6);
                    ?>

                    <h1><?php echo $count6; ?></h1>
                    <br />
                    Pending Orders
                </div>

                <div class="col-4 text-center">
                    
                    <?php 
                        //Sql Query 
                        $sql7 = "SELECT * FROM orders WHERE status = 'on Delivery'";
                        //Execute Query
                        $res7 = mysqli_query($conn, $sql7);
                        //Count Rows
                        $count7 = mysqli_num_rows($res7);
                    ?>

                    <h1><?php echo $count7; ?></h1>
                    <br />
                    On Delivery Orders
                </div>


                <div class="col-4 text-center">
                    
                    <?php 
                        //Sql Query 
                        $sql8 = "SELECT * FROM orders WHERE status = 'Cancelled'";
                        //Execute Query
                        $res8 = mysqli_query($conn, $sql8);
                        //Count Rows
                        $count8 = mysqli_num_rows($res8);
                    ?>

                    <h1><?php echo $count8; ?></h1>
                    <br />
                    Cancelled Orders
                </div>


                <div class="col-4 text-center">
                    
                    <?php 
                        //Sql Query 
                        $sql9 ="SELECT * FROM orders WHERE status = 'delivered'";
                        //Execute Query
                        $res9 = mysqli_query($conn, $sql9);
                        //Count Rows
                        $count9 = mysqli_num_rows($res9);
                    ?>

                    <h1><?php echo $count9; ?></h1>
                    <br />
                    Delivered Orders
                </div>
                <div class="col-4 text-center">
                    
                    <?php 
                        //Creat SQL Query to Get Total Revenue Generated
                        //Aggregate Function in SQL
                        $sql10 = "SELECT SUM(total_price) AS Total FROM orders WHERE status='Delivered'";

                        //Execute the Query
                        $res10 = mysqli_query($conn, $sql10);

                        //Get the VAlue
                        $row10 = mysqli_fetch_assoc($res10);
                        
                        //GEt the Total REvenue
                        $total_revenue = $row10['Total'];

                    ?>

                    <h1>&#8360;: <?php echo $total_revenue; ?></h1>
                    <br>
                    Revenue Generated
                </div>
                <div class="col-4 text-center">
                    
                    <?php 
                        //Sql Query 
                        $sql11 ="SELECT id FROM users";
                        //Execute Query
                        $res11 = mysqli_query($conn, $sql11);
                        //Count Rows
                        $count11 = mysqli_num_rows($res11);
                    ?>

                    <h1><?php echo $count11; ?></h1>
                    <br />
                    Users/ Customers
                </div>

                <div class="clearfix"></div>

            </div>
        </div>
        <!-- Main Content Setion Ends -->

<?php include('partials/footer.php') ?>