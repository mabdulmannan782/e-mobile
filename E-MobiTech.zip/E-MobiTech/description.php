<?php  
$id=$_GET['id'];
 require 'connection.php';
 require 'check_if_added.php';
 require 'header.php';
 $description='xyz';
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="assets/css/styles.css">
    <title>Products</title>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Lobster">
</head>
<body>
  <br>
  <br>
  <br><br><br>
  <div class="container">
                <table class="table table-bordered ">
                    <thead class="thead bg-dark">
                        <h3>Search  Products by  Brands</h3>
                        <tr>
                            <th> <a href="products.php?p=apple" class="btn btn-outline-dark">iPhone</a></th>
                            <th> <a href="products.php?p=samsung" class="btn btn-outline-dark">Samsung</a></th>
                            <th> <a href="products.php?p=vivo" class="btn btn-outline-dark">Vivo</a></th>
                            <th> <a href="products.php?p=oppo" class="btn btn-outline-dark">Oppo</a></th>
                            <th> <a href="products.php?p=xiaomi" class="btn btn-outline-dark">Xiaomi</a></th>
                            <th> <a href="products.php?p=nokia" class="btn btn-outline-dark">Nokia</a></th>
                            <th> <a href="products.php?p=gionee" class="btn btn-outline-dark">Gionee</a></th>
                            <th> <a href="products.php?p=anker" class="btn btn-outline-dark">Anker</a></th>
                        </tr>
</thead>
</table>
</div><br>
<section class="brands section bd-container">
    <div class="row">
    <?php
      $query="SELECT * FROM `items` WHERE id='$id' ";
     $queryfire=mysqli_query($con,$query);
     $num=mysqli_num_rows($queryfire);
     if($num > 0){
        while($product =mysqli_fetch_array($queryfire)){ 
            ?>
              <div class="card">
                  <h6 class="card-title bg-dark text-white p-2 text-uppercase text-center"> <?php echo $product['title']; ?> </h6>
                   <div class= "card-body">
                   <img src="assets/img/<?php echo $product['image'];?>" class="img-fluid m-2" >
                    <h6><s> &#8360; <?php echo  $product['price']; ?></s></h6>
                    <h4>&#8360; <?php echo  $product['new_price']; ?><span>(<?php echo  $product['discount']; ?> % OFF)</span></h4>
                     <h4 class="badge badge-success"> <?php echo  $product['rating']; ?> <i class="fa fa-star"> </i> </h4>
                  </div>
                  <?php if(!isset($_SESSION['email'])){  ?>
                                        <p><a href="login.php" role="button" class="accessory__button btn-danger">Buy Now</a></p>
                                        <?php
                                        }
                                        else{
                                            if(check_if_added_to_cart($product['id'])){
                                                echo '<a href="cart.php" class="accessory__button btn-success disabled">Added to cart</a>';
                                            }else{
                                                ?>
                                                <a href="cart_add.php? id=<?php echo $product['id']?>"  name="add" value="add" class="accessory__button btn-danger">Add to cart</a>
                                                <?php
                                            }
                                        }
                                        ?>
                 </div>
             <br>
             <?php
              $description=$product['description'];
         }
   } 
   ?>
   </div>
  </selection>
  <div class="container" align="center">
    <br><br><br>
    <h2> The Description of the Product is here ____ </h2><br><br>
    <h4><?php echo $description;  ?> </h4>
    </div>
  <?php include("footer.php") ; ?>
</body>
</html>